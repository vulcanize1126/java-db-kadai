package com.example.samuraitravel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamuraitravelApplicationTests {

	@Test
	void contextLoads() {
	}

}
