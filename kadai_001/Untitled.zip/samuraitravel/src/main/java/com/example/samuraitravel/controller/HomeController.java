package com.example.samuraitravel.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
//アノテーション（@)をつけて、このクラスがコントローラとして機能するようにする。
@Controller
public class HomeController {
  @GetMapping("/")
   public String index() {
	  //メソッドの最後にビューの名前をreturnで返す（.html省略）
     return "index";
  }   
}
